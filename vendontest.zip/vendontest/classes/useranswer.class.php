<?php
include 'includes/autoloader.inc.php';
//Answers
$answer = new user();
$tester = new user();
